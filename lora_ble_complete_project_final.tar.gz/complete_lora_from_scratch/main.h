#ifndef _MAIN_H_
#define _MAIN_H_

//void ble_init(void);



#endif


