# Claude任务说明：完善LoRa-BLE完整源码

## 项目来源
### 1. LoRa核心部分（反编译自44KB固件）
- UserApp/user_app.c (LoRa版本应用逻辑)
- main.c (LoRa版本主程序)
- config.h (LoRa硬件配置)

### 2. 项目结构部分（从4G项目复制）
- Keil项目文件 (.uvprojx, .uvoptx)
- Include目录 (头文件)
- 驱动文件 (flash.c, uart.c等)
- profile目录 (蓝牙配置)

## 需要Claude完善的工作

### 1. 验证和补充LoRa驱动
- 检查E220-M900T22S驱动代码是否完整
- 补充缺失的LoRa相关文件
- 验证UART通信配置

### 2. 清理4G相关代码
- 移除4G特定的网络代码
- 保留蓝牙和基础功能
- 确保LoRa功能完整

### 3. 移植0x21密码修改功能
从4G项目的user_app.c中移植：
- 0x21命令处理（第1775行开始）
- 密码存储逻辑（SystemParameter）
- 响应协议：AA 01 21 00 YY

### 4. 项目配置调整
- 调整Keil项目配置为LoRa目标
- 确认编译生成44KB固件
- 验证内存映射和链接配置

### 5. 编译测试
- 编译生成.bin文件
- 验证文件大小为44KB左右
- 测试基本功能

## 文件说明
### 关键文件位置
- **Keil/SYD8811_LoRa_BLE_Lock_V01.uvprojx** - Keil项目文件
- **UserApp/user_app.c** - 主要应用逻辑（需要修改）
- **main.c** - 主程序文件
- **config.h** - 硬件配置文件

### 需要关注的代码
1. **LoRa驱动**：查找E220-M900T22S相关代码
2. **蓝牙部分**：保持与4G项目兼容
3. **0x21命令**：需要从4G项目移植

## 预期成果
1. 完整的可编译LoRa-BLE Keil项目
2. 包含0x21密码修改功能
3. 生成44KB的固件文件
4. LoRa和蓝牙功能正常

## 时间要求
尽快完成，今天内提供可测试的固件。
